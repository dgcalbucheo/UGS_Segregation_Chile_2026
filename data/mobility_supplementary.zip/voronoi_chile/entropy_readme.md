# Supplementary Mobility Datasets

This archive contains the supplementary datasets derived from anonymized mobile phone records (XDR, MOVISTAR) used in:

Calbucheo et al. (2026). *[Título del paper]*.

## Contents

### Hourly entropy tables

- `hourly_entropy_antofagasta.xlsx`
- `hourly_entropy_concepcion.xlsx`
- `hourly_entropy_laserena.xlsx`
- `hourly_entropy_puertomontt.xlsx`
- `hourly_entropy_santiago.xlsx`
- `hourly_entropy_valparaiso.xlsx`

Each file contains the hourly social entropy values calculated for every public park in the corresponding conurbation.

### Voronoi polygons

- `voronoi_ismt_chile.gpkg`

GeoPackage containing the Voronoi tessellation generated from mobile phone antennas. Each polygon is associated with an ISMT value and was used to estimate the socioeconomic status of park visitors.

## Notes

The original XDR mobile phone records are proprietary and cannot be publicly distributed. This archive provides the processed datasets required to reproduce the analyses presented in the manuscript.